<!-- Auto-generated from JSON by GDScript docs maker. Do not edit this document directly. -->

# ReferenceCollector #

**Extends:** EditorScript

## Description ##

## Properties ##

Type | Name
 --- | --- 
SceneTree | Collector
Array | directories
bool | is_recursive
Array | patterns
String | save_path

## Methods ##

Type | Name
 --- | --- 

## Property Descriptions ##

### Collector ###

```gdscript
var Collector: SceneTree
```

### directories ###

```gdscript
var directories: Array
```

A list of directories to collect files from.

### is\_recursive ###

```gdscript
var is_recursive: bool
```

If true, explore each directory recursively

### patterns ###

```gdscript
var patterns: Array
```

A list of patterns to filter files.

### save\_path ###

```gdscript
var save_path: String
```

Output path to save the class reference.