<!-- Auto-generated from JSON by GDScript docs maker. Do not edit this document directly. -->

# Bullet #

**Extends:** RigidBody2D

## Description ##

## Properties ##

Type | Name
 --- | --- 
var | animation_player

## Methods ##

Type | Name
 --- | --- 
var | func destroy()

## Property Descriptions ##

### animation\_player ###

```gdscript
var animation_player
```

## Method Descriptions ##

### destroy ###

```gdscript
func destroy()
```
