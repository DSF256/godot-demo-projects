<!-- Auto-generated from JSON by GDScript docs maker. Do not edit this document directly. -->

# Coin #

**Extends:** Area2D

## Description ##

## Properties ##

Type | Name
 --- | --- 
var | animation_player

## Methods ##

Type | Name
 --- | --- 

## Signals ##

- signal coinCollected()

## Property Descriptions ##

### animation\_player ###

```gdscript
var animation_player
```

