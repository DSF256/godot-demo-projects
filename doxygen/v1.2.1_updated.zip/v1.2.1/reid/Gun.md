<!-- Auto-generated from JSON by GDScript docs maker. Do not edit this document directly. -->

# Gun #

**Extends:** Position2D

## Description ##

## Properties ##

Type | Name
 --- | --- 
var | sound_shoot
var | timer

## Methods ##

Type | Name
 --- | --- 
var | func shoot(direction = 1)

## Property Descriptions ##

### sound\_shoot ###

```gdscript
var sound_shoot
```

### timer ###

```gdscript
var timer
```

## Method Descriptions ##

### shoot ###

```gdscript
func shoot(direction = 1)
```
