<!-- Auto-generated from JSON by GDScript docs maker. Do not edit this document directly. -->

# Actor #

**Extends:** KinematicBody2D

## Description ##

## Properties ##

Type | Name
 --- | --- 
var | speed
var | gravity

## Methods ##

Type | Name
 --- | --- 

## Property Descriptions ##

### speed ###

```gdscript
export var speed = "(150, 350)"
```

### gravity ###

```gdscript
var gravity
```

